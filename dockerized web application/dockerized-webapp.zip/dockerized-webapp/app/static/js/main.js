// Fetch health status on page load
async function checkHealth() {
  const el = document.getElementById('health-status');
  const card = document.getElementById('health-card');
  try {
    const res = await fetch('/health');
    const data = await res.json();
    if (data.status === 'healthy') {
      el.textContent = '✅ Healthy';
      el.style.color = '#4ade80';
    } else {
      el.textContent = '⚠️ Degraded';
      el.style.color = '#fb923c';
    }
  } catch (e) {
    el.textContent = '❌ Unreachable';
    el.style.color = '#f87171';
  }
}

// Auto-refresh every 30 seconds
checkHealth();
setInterval(checkHealth, 30000);

// Highlight nav link for current page
document.querySelectorAll('nav a').forEach(link => {
  if (link.href === window.location.href) {
    link.style.color = '#60a5fa';
    link.style.fontWeight = '600';
  }
});
